﻿using System;

namespace ExceptionsHomework
{
    public abstract class Exam
    {
        public abstract ExamResult Check();
    }
}
