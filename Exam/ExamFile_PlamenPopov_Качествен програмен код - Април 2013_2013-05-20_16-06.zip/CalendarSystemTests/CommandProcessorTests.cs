﻿namespace CalendarSystemTests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class CommandProcessorTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}