﻿namespace Cooking
{
    using System;

    /// <summary>
    /// Potato class.
    /// </summary>
    public class Potato : Vegetable
    {
        /// <summary>
        /// Initializes a new instance of the Potato class.
        /// </summary>
        public Potato()
        {
        }
    }
}