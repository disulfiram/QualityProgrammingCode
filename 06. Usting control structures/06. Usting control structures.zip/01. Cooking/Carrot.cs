﻿namespace Cooking
{
    using System;

    /// <summary>
    /// Carrot class.
    /// </summary>
    public class Carrot : Vegetable
    {
        /// <summary>
        /// Initializes a new instance of the Carrot class.
        /// </summary>
        public Carrot()
        {
        }
    }
}