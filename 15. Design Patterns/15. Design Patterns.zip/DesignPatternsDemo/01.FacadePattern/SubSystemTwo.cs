﻿using System;

namespace FacadePattern
{
    public class SubSystemTwo
    {
        public void MethodTwo()
        {
            Console.WriteLine("Method Two");
        }
    }
}
