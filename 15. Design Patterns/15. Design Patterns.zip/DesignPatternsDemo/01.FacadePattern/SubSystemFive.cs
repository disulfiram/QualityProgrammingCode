﻿using System;

namespace FacadePattern
{
    public class SubSystemFive
    {
        public void MethodFive()
        {
            Console.WriteLine("Method Five");
        }
    }
}
