﻿using System;

namespace FacadePattern
{
    public class SubSystemOne
    {
        public void MethodOne()
        {
            Console.WriteLine("Method One");
        }
    }
}
