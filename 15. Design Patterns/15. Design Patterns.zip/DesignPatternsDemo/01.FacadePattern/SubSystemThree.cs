﻿using System;

namespace FacadePattern
{
    public class SubSystemThree
    {
        public void MethodThree()
        {
            Console.WriteLine("Method Three");
        }
    }
}
