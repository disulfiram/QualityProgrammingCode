﻿using System;

namespace FacadePattern
{
    public class SubSystemFour
    {
        public void MethodFour()
        {
            Console.WriteLine("Method Four");
        }
    }
}
